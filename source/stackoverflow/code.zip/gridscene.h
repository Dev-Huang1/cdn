// gridscene.h
#ifndef GRIDSCENE_H
#define GRIDSCENE_H

#include <QGraphicsScene>

class GridScene : public QGraphicsScene {
public:
    GridScene(QObject *parent = nullptr);
};

#endif // GRIDSCENE_H
