// gridscene.cpp
#include "gridscene.h"
#include <QPen>
#include <QGraphicsTextItem>
#include <QFont>
#include <QDebug>

GridScene::GridScene(QObject *parent) : QGraphicsScene(parent) {
    qDebug() << "GridScene class started";
    const int gridSize = 20;  // Distance between grid lines
    const int sceneWidth = 731;  // Match QGraphicsView width
    const int sceneHeight = 421; // Match QGraphicsView height
    setSceneRect(0, 0, sceneWidth, sceneHeight);
    QFont font;
    font.setPointSize(8);

    for (int y = 0; y <= sceneHeight; y += gridSize) {
        addLine(0, y, sceneWidth, y, QPen(Qt::gray));
        QGraphicsTextItem *textItem = addText(QString::number(y), font);
        textItem->setPos(-30, y - 5);  //left
        textItem->setDefaultTextColor(Qt::white);
        textItem->show();
    }

    for (int x = 0; x <= sceneWidth; x += gridSize) {
        addLine(x, 0, x, sceneHeight, QPen(Qt::gray));
        QGraphicsTextItem *textItem = addText(QString::number(x), font);
        textItem->setPos(x - 10, -20); //above
        textItem->setDefaultTextColor(Qt::green);
        textItem->show();
    }
}
